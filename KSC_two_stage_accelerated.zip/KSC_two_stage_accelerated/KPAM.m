function W=KPAM(Z,KZD,KDD,atoms,iter,exit_tol,sparsity) 
%% Initialize
columns_z=size(Z,2);
W=zeros(atoms,columns_z);

EigMax=max(eig(KDD));

% points = linspace(1.001, 1.5, 200);
% points=sort(points,'descend');

%% KPAM
for h=1:iter
    W_old=W;
    GW=-KZD'+KDD*W;
    s=1.1*EigMax;    % points(h)*EigMax;  % ����
    W=W-GW/s;
    for i=1:columns_z
        w=W(:,i);
        w_abs=abs(w);
        [~, ind] = sort(w_abs, 'descend');
        topSInd = ind(1:sparsity(i));
        result = zeros(atoms,1);
        result(topSInd) = w(topSInd);
        W(:,i)=result;  
    end
    
    %%  stopping criterion
    loss(h)=columns_z-trace(2*KZD*W)+trace(W'*KDD*W);
    if h>1
        error=abs(loss(h)-loss(h-1));
        Error_W = norm(W-W_old,'fro')/norm(W_old,'fro');
        if  error<exit_tol && Error_W < exit_tol
            fprintf('KPAM reached exit tolerance at iter %d\n',h);
            break;
        end
    end
end
end