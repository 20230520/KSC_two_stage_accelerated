clear;clc;

%% Parameter initialization
exit_tol=1e-3;
iter=200;
sigma=1.5;
% lambda=[0.001, 0.005, 0.01:0.03:0.2]; % �����������ݼ�Ӧ�ö���������
lambda=0.05:0.004:0.15;

load('D:\Dataset\��ʦ��\PlanetLab\PlanetLabData.mat')
Q=data;

%% Train data --Y
Y0 = squeeze(Q(:, :, 1));
[rows_y,columns_y]=size(Y0);
Y=zeros(rows_y,columns_y);
for i=1:columns_y
    Y(:,i)=Y0(:,i)./norm(Y0(:,i));
end

atoms=rows_y;


%% Test data --Z
Z0 = squeeze(Q(:, :, 2));
[rows_z,columns_z]=size(Z0);
Z=zeros(rows_z,columns_z);
for i=1:columns_z
    Z(:,i)=Z0(:,i)./norm(Z0(:,i));
end
nZ=numel(Z);

%% ��ʼ��
T_KCD=zeros(length(lambda),1);
Object_KCD=zeros(length(lambda),1);
NRMSE_KCD=zeros(length(lambda),1);
NMAE_KCD=zeros(length(lambda),1);
No_KCD=zeros(length(lambda),1);
CR_KCD=zeros(length(lambda),1);

T_FKCD=zeros(length(lambda),1);
Object_FKCD=zeros(length(lambda),1);
NRMSE_FKCD=zeros(length(lambda),1);
NMAE_FKCD=zeros(length(lambda),1);
No_FKCD=zeros(length(lambda),1);

T_KPAM=zeros(length(lambda),1);
Object_KPAM=zeros(length(lambda),1);
NRMSE_KPAM=zeros(length(lambda),1);
NMAE_KPAM=zeros(length(lambda),1);
No_KPAM=zeros(length(lambda),1);

T_Knorm21=zeros(length(lambda),1);
Object_Knorm21=zeros(length(lambda),1);
NRMSE_Knorm21=zeros(length(lambda),1);
NMAE_Knorm21=zeros(length(lambda),1);
No_Knorm21=zeros(length(lambda),1);

T_Kfro=zeros(length(lambda),1);
Object_Kfro=zeros(length(lambda),1);
NRMSE_Kfro=zeros(length(lambda),1);
NMAE_Kfro=zeros(length(lambda),1);
No_Kfro=zeros(length(lambda),1);

T_CD=zeros(length(lambda),1);
Object_CD=zeros(length(lambda),1);
NRMSE_CD=zeros(length(lambda),1);
NMAE_CD=zeros(length(lambda),1);
No_CD=zeros(length(lambda),1);

for L=1:length(lambda)
    %% ==================================== step1.Train ===========================================
    D=KCD_Newton_sigma(Y,lambda(L),sigma,atoms,iter,exit_tol);
    
    %% ==================================== step2.Test ===========================================
    %% ===========================step2.feature space =======================
    KDD=kernel_rbf_sigma(sigma,D,D);
    KZD=kernel_rbf_sigma(sigma,Z,D);
    
    KDD_rowNorms=zeros(atoms,1);
    for i=1:atoms
        KDD_rowNorms(i)=norm(KDD(i,:),2);
    end
    
    %% KCD_z
    W_KCD=zeros(atoms,columns_z);
    Z_KCD=zeros(rows_z,columns_z);
    
    t_KCD=tic;
    for c=1:columns_z
        KzD=KZD(c,:);
        W_KCD(:,c)=KCD(atoms,KzD,KDD,lambda(L),iter,exit_tol);
    end
    T_KCD(L)=toc(t_KCD);
    sparsity=sum(W_KCD~=0,1);
    
    for c=1:columns_z
        w_KCD=W_KCD(:,c);
        Z_KCD(:,c)=y_KGD(D,KDD,w_KCD,sigma,iter,exit_tol);
    end
    Object_KCD(L)=columns_z-trace(2*KZD*W_KCD)+trace(W_KCD'*KDD*W_KCD);
    NRMSE_KCD(L)=norm(Z-Z_KCD,'fro')/norm(Z,'fro'); 
    
    ZZ_KCD=Z-Z_KCD;
    NMAE_KCD(L)=sum(abs(ZZ_KCD(:)))/sum(abs(Z(:)));
    
    Logic_KCD=abs(ZZ_KCD)<exit_tol;
    No_KCD(L)=sum(Logic_KCD(:));
    
    nnz_KCD=sum(sparsity);
    CR_KCD(L)=nZ/nnz_KCD;
             
    %% FKCD
    W_FKCD=zeros(atoms,columns_z);
    Z_FKCD=zeros(rows_z,columns_z);
    
    t_FKCD=tic;
    for c=1:columns_z
        KzD=KZD(c,:);
        W_FKCD(:,c)=KCD_fast(atoms,KzD,KDD,KDD_rowNorms,lambda(L),iter,exit_tol);
    end
    T_FKCD(L)=toc(t_FKCD);
    for c=1:columns_z
        w_FKCD=W_FKCD(:,c);
        Z_FKCD(:,c)=y_KGD(D,KDD,w_FKCD,sigma,iter,exit_tol);
    end
    Object_FKCD(L)=columns_z-trace(2*KZD*W_FKCD)+trace(W_FKCD'*KDD*W_FKCD);
    NRMSE_FKCD(L)=norm(Z-Z_FKCD,'fro')/norm(Z,'fro');
    
    ZZ_FKCD=Z-Z_FKCD;
    NMAE_FKCD(L)=sum(abs(ZZ_FKCD(:)))/sum(abs(Z(:)));
    
    Logic_FKCD=abs(ZZ_FKCD)<exit_tol;
    No_FKCD(L)=sum(Logic_FKCD(:));
       
    %% PAM_2016
    sigma_KPAM=5;
    KDD_KPAM=kernel_rbf_sigma(sigma_KPAM,D,D);
    KZD_KPAM=kernel_rbf_sigma(sigma_KPAM,Z,D);
    Z_KPAM=zeros(rows_z,columns_z);
    
    t_KPAM=tic;
    W_KPAM=KPAM(Z,KZD_KPAM,KDD_KPAM,atoms,iter,exit_tol,sparsity);  
    T_KPAM(L)=toc(t_KPAM);
    Object_KPAM(L)=columns_z-trace(2*KZD_KPAM*W_KPAM)+trace(W_KPAM'*KDD_KPAM*W_KPAM);

    for c=1:columns_z
        w=W_KPAM(:,c);
        Z_KPAM(:,c)=y_KGD(D,KDD,w,sigma,iter,exit_tol);
    end
    NRMSE_KPAM(L)=norm(Z-Z_KPAM,'fro')/norm(Z,'fro');
    
    ZZ_KPAM=Z-Z_KPAM;
    NMAE_KPAM(L)=sum(abs(ZZ_KPAM(:)))/sum(abs(Z(:)));
    
    Logic_KPAM=abs(ZZ_KPAM)<exit_tol;
    No_KPAM(L)=sum(Logic_KPAM(:));
    
    %% KOMP
%     t_KOMP=tic;
%     W_KOMP=KOMP2(Z,KDD,KZD,atoms,sparsity);
%     T_KOMP(L)=toc(t_KOMP);
%     Object_KOMP(L)=columns_z-trace(2*KZD*W_KOMP)+trace(W_KOMP'*KDD*W_KOMP);
%     Z_KOMP=[];
%     for j=1:columns_z
%         w=W_KOMP(:,j);
%         z_KOMP=y_KGD(D,KDD,w,sigma,iter,exit_tol);
%         Z_KOMP=[Z_KOMP z_KOMP];
%     end
%     LOSS_KOMP(L)=norm(Z-Z_KOMP,'fro')/norm(Z,'fro');
%     
%     ZZ_KOMP=Z-Z_KOMP;
%     logical_KOMP = abs(ZZ_KOMP) < prox;  
%     N_KOMP(L)=sum(logical_KOMP(:));
    
    %% KSR_norm21
    Z_Knorm21=zeros(rows_z,columns_z);
    
    t_Knorm21=tic;
    W_Knorm21=Knorm21(Z,KDD,KZD,atoms,lambda(L),iter,exit_tol,sparsity);
    T_Knorm21(L)=toc(t_Knorm21);
    Object_Knorm21(L)=columns_z-trace(2*KZD* W_Knorm21)+trace(W_Knorm21'*KDD* W_Knorm21);

    for c=1:columns_z
        w=W_Knorm21(:,c);
        Z_Knorm21(:,c)=y_KGD(D,KDD,w,sigma,iter,exit_tol);
    end
    NRMSE_Knorm21(L)=norm(Z-Z_Knorm21,'fro')/norm(Z,'fro');
    
    ZZ_Knorm21=Z-Z_Knorm21;
    NMAE_Knorm21(L)=sum(abs(ZZ_Knorm21(:)))/sum(abs(Z(:)));
    
    Logic_Knorm21=abs(ZZ_Knorm21)<exit_tol;
    No_Knorm21(L)=sum(Logic_Knorm21(:));

    %% KSR_norm_fro
    Z_Kfro=zeros(rows_z,columns_z);
    
    t_Kfro=tic;
    W_Kfro=Kfro(Z,KDD,KZD,atoms,lambda(L),iter,exit_tol,sparsity);
    T_Kfro(L)=toc(t_Kfro);
    Object_Kfro(L)=columns_z-trace(2*KZD* W_Kfro)+trace( W_Kfro'*KDD* W_Kfro);

    for c=1:columns_z
        w=W_Kfro(:,c);
        Z_Kfro(:,c)=y_KGD(D,KDD,w,sigma,iter,exit_tol);
    end
    NRMSE_Kfro(L)=norm(Z-Z_Kfro,'fro')/norm(Z,'fro');
    
    ZZ_Kfro=Z-Z_Kfro;
    NMAE_Kfro(L)=sum(abs(ZZ_Kfro(:)))/sum(abs(Z(:)));
    
    Logic_Kfro=abs(ZZ_Kfro)<exit_tol;
    No_Kfro(L)=sum(Logic_Kfro(:));
    
    %% ==========================step2.orginal space ========================
    %% CD
    W_CD=zeros(atoms,columns_z);
    
    t_CD=tic;
    for c=1:columns_z
        z=Z(:,c);
        W_CD(:,c)=CD(atoms,z,D,lambda(L),iter,exit_tol,sparsity(c));
    end
    T_CD(L)=toc(t_CD);
    Object_CD(L)=columns_z-trace(2*KZD*W_CD)+trace( W_CD'*KDD*W_CD);
    NRMSE_CD(L)=norm(Z-D*W_CD,'fro')/norm(Z,'fro');
    
    ZZ_CD=Z-D*W_CD;
    NMAE_CD(L)=sum(abs(ZZ_CD(:)))/sum(abs(Z(:)));
    
    Logic_CD=abs(ZZ_CD)<exit_tol;
    No_CD(L)=sum(Logic_CD(:));
end

figure(1);
plot(CR_KCD,NRMSE_KCD,'-o', 'LineWidth', 2); hold on;
plot(CR_KCD,NRMSE_FKCD,'--x', 'LineWidth', 2); hold on;
plot(CR_KCD,NRMSE_KPAM,'-d', 'LineWidth', 2); hold on;
plot(CR_KCD,NRMSE_Knorm21,'-^', 'LineWidth', 2); hold on;
plot(CR_KCD,NRMSE_Kfro,'-^', 'LineWidth', 2); hold on;
plot(CR_KCD,NRMSE_CD,'-s', 'LineWidth', 2); 
xlabel('CR','FontSize', 16);
ylabel('NRMSE','FontSize', 16);
title('PlanetLab','FontSize', 16)
legend('KCD','FKCD','LPM','KSR-L_{2,1}','KFMC','CD')
l = legend;  
l.FontSize = 16; 
grid on; 

figure(2);
plot(CR_KCD,NMAE_KCD,'-o', 'LineWidth', 2); hold on;
plot(CR_KCD,NMAE_FKCD,'--x', 'LineWidth', 2); hold on;
plot(CR_KCD,NMAE_KPAM,'-d', 'LineWidth', 2); hold on;
plot(CR_KCD,NMAE_Knorm21,'-^', 'LineWidth', 2); hold on;
plot(CR_KCD,NMAE_Kfro,'-^', 'LineWidth', 2); hold on;
plot(CR_KCD,NMAE_CD,'-s', 'LineWidth', 2); 
xlabel('CR','FontSize', 16);
ylabel('NMAE','FontSize', 16);
title('PlanetLab','FontSize', 16)
legend('KCD','FKCD','LPM','KSR-L_{2,1}','KFMC','CD')
l = legend;  
l.FontSize = 16; 
grid on;

figure(3);
plot(CR_KCD,No_KCD,'-o', 'LineWidth', 2); hold on;
plot(CR_KCD,No_FKCD,'--x', 'LineWidth', 2); hold on;
plot(CR_KCD,No_KPAM,'-d', 'LineWidth', 2); hold on;
plot(CR_KCD,No_Knorm21,'-^', 'LineWidth', 2); hold on;
plot(CR_KCD,No_Kfro,'-^', 'LineWidth', 2); hold on;
plot(CR_KCD,No_CD,'-s', 'LineWidth', 2); 
xlabel('CR','FontSize', 16);
ylabel('No. of correctly recovered','FontSize', 16);
title('PlanetLab','FontSize', 16)
legend('KCD','FKCD','LPM','KSR-L_{2,1}','KFMC','CD')
l = legend;  
l.FontSize = 16; 
grid on;

% [CR_KCD2, I_KCD] = sort(CR_KCD);
% 
% NRMSE_KCD2 = NRMSE_KCD(I_KCD);
% NRMSE_FKCD2 = NRMSE_FKCD(I_KCD);
% NRMSE_KPAM2=NRMSE_KPAM(I_KCD);
% NRMSE_Knorm212=NRMSE_Knorm21(I_KCD);
% NRMSE_Kfro2=NRMSE_Kfro(I_KCD);
% NRMSE_CD2=NRMSE_CD(I_KCD);
% 
% NMAE_KCD2=NMAE_KCD(I_KCD);
% NMAE_FKCD2=NMAE_FKCD(I_KCD);
% NMAE_KPAM2=NMAE_KPAM(I_KCD);
% NMAE_Knorm212=NMAE_Knorm21(I_KCD);
% NMAE_Kfro2=NMAE_Kfro(I_KCD);
% NMAE_CD2=NMAE_CD(I_KCD);
% 
% No_KCD2=No_KCD(I_KCD);
% No_FKCD2=No_FKCD(I_KCD);
% No_KPAM2=No_KPAM(I_KCD);
% No_Knorm212=No_Knorm21(I_KCD);
% No_Kfro2=No_Kfro(I_KCD);
% No_CD2=No_CD(I_KCD);
% 
% figure(1);
% plot(CR_KCD2,NRMSE_KCD2,'-o', 'LineWidth', 2); hold on;
% plot(CR_KCD2,NRMSE_FKCD2,'--x', 'LineWidth', 2); hold on;
% plot(CR_KCD2,NRMSE_KPAM2,'-d', 'LineWidth', 2); hold on;
% plot(CR_KCD2,NRMSE_Knorm212,'-^', 'LineWidth', 2); hold on;
% plot(CR_KCD2,NRMSE_Kfro2,'-^', 'LineWidth', 2); hold on;
% plot(CR_KCD2,NRMSE_CD2,'-s', 'LineWidth', 2); 
% xlabel('CR','FontSize', 16);
% ylabel('NRMSE','FontSize', 16);
% title('PlanetLab','FontSize', 16)
% legend('KCD','FKCD','LPM','KSR-L_{2,1}','KFMC','CD')
% l = legend;  
% l.FontSize = 16; 
% grid on; 
% 
% figure(2);
% plot(CR_KCD2,NMAE_KCD2,'-o', 'LineWidth', 2); hold on;
% plot(CR_KCD2,NMAE_FKCD2,'--x', 'LineWidth', 2); hold on;
% plot(CR_KCD2,NMAE_KPAM2,'-d', 'LineWidth', 2); hold on;
% plot(CR_KCD2,NMAE_Knorm212,'-^', 'LineWidth', 2); hold on;
% plot(CR_KCD2,NMAE_Kfro2,'-^', 'LineWidth', 2); hold on;
% plot(CR_KCD2,NMAE_CD2,'-s', 'LineWidth', 2); 
% xlabel('CR','FontSize', 16);
% ylabel('NMAE','FontSize', 16);
% title('PlanetLab','FontSize', 16)
% legend('KCD','FKCD','LPM','KSR-L_{2,1}','KFMC','CD')
% l = legend;  
% l.FontSize = 16; 
% grid on;
% 
% figure(3);
% plot(CR_KCD2,No_KCD2,'-o', 'LineWidth', 2); hold on;
% plot(CR_KCD2,No_FKCD2,'--x', 'LineWidth', 2); hold on;
% plot(CR_KCD2,No_KPAM2,'-d', 'LineWidth', 2); hold on;
% plot(CR_KCD2,No_Knorm212,'-^', 'LineWidth', 2); hold on;
% plot(CR_KCD2,No_Kfro2,'-^', 'LineWidth', 2); hold on;
% plot(CR_KCD2,No_CD2,'-s', 'LineWidth', 2); 
% xlabel('CR','FontSize', 16);
% ylabel('No. of correctly recovered','FontSize', 16);
% title('PlanetLab','FontSize', 16)
% legend('KCD','FKCD','LPM','KSR-L_{2,1}','KFMC','CD')
% l = legend;  
% l.FontSize = 16; 
% grid on;
