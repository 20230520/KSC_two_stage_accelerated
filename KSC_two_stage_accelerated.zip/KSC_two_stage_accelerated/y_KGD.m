function y=y_KGD(D,KDD,w,sigma,iter,exit_tol)

sigma2=sigma^2;  % rbf hyperparameters
[rows_D,~]=size(D);

%% initialize
% delta=0.01;  % step size of the gradient descent
rho=1.1;
y=zeros(rows_D,1); % y=rand(rows_D,1);
KyD=kernel_rbf_sigma(sigma,y,D);  %  NaN Դͷ��

% Y=[];
for h=1:iter;
    %% y1
    y_old=y;
    Gy=-D*(KyD'.*w)/sigma2+KyD*w*y/sigma2;
    Ly=KyD*w/sigma2;
    y=y-Gy/(rho*Ly); 
    KyD=kernel_rbf_sigma(sigma,y,D);  %  NaN Դͷ��
    
    %% stopping criterion
    loss(h)=1-2*KyD*w+w'*KDD*w;
    if h>1
        error(h)=abs(loss(h)-loss(h-1));
        Error_y(h)=norm(y-y_old,2)/norm(y_old,2);
        if  error(h)<exit_tol && Error_y(h) < exit_tol
            fprintf('y_KGD reached exit tolerance at iter %d\n',h);
            break;
        end
    end
end
end

%  %% stopping criterion1
%     loss(h)=1-2*KyD*w+w'*KDD*w;
%     if h>1
%         error=abs(loss(h)-loss(h-1));
%         if  error<exit_tol
%             fprintf('y_KGD reached exit tolerance at iter %d\n',h);
%             break;
%         end
%     end
%     %% stopping criterion2
%     Error_y(h)=norm(y-y_old,2)/norm(y_old,2);
%     if Error_y(h) < exit_tol
%         fprintf('Z_KGD reached exit tolerance at iter %d\n',h);
%         break
%     end