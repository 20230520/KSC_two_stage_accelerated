% �Ľ�����0��-1�ε���Ϊ�㣬��1��2���������£��ӵ����ο�ʼ�����½����
% phi(y)=phi(D)w

function w=KCD_fast(atoms,KyD,KDD,KDD_rowNorms,lambda,iter,exit_tol)  % W��w�ĵ�������

%% initialize
% w=inv(KDD+0.001*eye(atoms))*(KyD');  % w^{0}
w=zeros(atoms,1);
z=zeros(atoms,1);

%% Initially updated normally
for h=1:2;
    w_old=w;
    for i=1:atoms
        z(i)=KyD(i)-KDD(i,:)*w+KDD(i,i)*w(i);
        if z(i)>lambda
            w(i) = z(i)-lambda;
        elseif z(i)<-lambda
            w(i) = z(i)+lambda;
        else
            w(i) = 0;
        end
    end
end
Dw=w-w_old;
DwiNorm=norm(Dw);
        
%% Skip zero weights
for h=3:iter
    w_old=w;
    for i=1:atoms
        if i==1
            DwiNorm=sqrt(DwiNorm^2-Dw(i)^2);
        else
            DwiNorm=sqrt(DwiNorm^2-Dw(i)^2+Dw(i-1)^2);
        end
        Theta= KDD_rowNorms(i)*DwiNorm;
        z_upper=z(i)+Theta;
        z_lower=z(i)-Theta;
        if z_upper<lambda && z_lower>-lambda
            w(i) = 0;        %  һ����ûԤ�⵽ ������
        else
            z(i)=KyD(i)-KDD(i,:)*w+KDD(i,i)*w(i);
            if z(i)>lambda
                w(i) = z(i)-lambda;
            elseif z(i)<-lambda
                w(i) = z(i)+lambda;
            else
                w(i) = 0;
            end
        end
        Dw(i)=w(i)-w_old(i);
    end
    DwiNorm=sqrt(DwiNorm+Dw(i)^2); % DwiNorm=norm(Dw,2);
    
    %% stopping criterion
    loss(h)=1-2*KyD*w+w'*KDD*w;
    
    if h>1
        error=abs(loss(h)-loss(h-1));
        Error_w = norm(w-w_old,2)/norm(w_old,2);
        if  error<exit_tol && Error_w < exit_tol
            fprintf('KCD_fast reached exit tolerance at iter %d\n',h);
            break;
        end
    end
end
end

